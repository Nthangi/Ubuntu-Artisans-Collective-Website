// Mobile menu toggle + simple client-side validation (small)
document.addEventListener('DOMContentLoaded', function(){
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('.nav ul');
  
    if(toggle){
      toggle.addEventListener('click', function(){
        const expanded = this.getAttribute('aria-expanded') === 'true';
        this.setAttribute('aria-expanded', String(!expanded));
        nav.classList.toggle('open');
      });
    }
  
    // Simple contact/enquiry client validation (optional)
    const forms = document.querySelectorAll('form.needs-validation');
    forms.forEach(form => {
      form.addEventListener('submit', e => {
        if(!form.checkValidity()){
          e.preventDefault();
          e.stopPropagation();
          form.classList.add('was-validated');
          alert('Please fill all required fields correctly.');
        }
      });
    });
  });
  